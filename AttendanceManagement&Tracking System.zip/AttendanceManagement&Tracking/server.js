require('dotenv').config();

const https = require('https');
const fs = require('fs');
const express = require('express');
const cors = require('cors'); // Import the cors module
const mysql = require('mysql2'); // Import the mysql module
const qr = require('qr-image'); // Import the qr-image module

const app = express();

app.use(cors());
app.use(express.json());

const sslOptions = {
  key: fs.readFileSync(process.env.SSL_KEY_FILE),
  cert: fs.readFileSync(process.env.SSL_CRT_FILE)
};

const server = https.createServer(sslOptions, app);

const db = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: 'dell123',
  database: 'college'
});

db.connect(err => {
  if (err) {
    console.error('Error connecting to database:', err);
  } else {
    console.log('Connected to database');
  }
});

server.listen(5000, '0.0.0.0', () => {
  console.log('Server is running on port 5000');
});

app.post('/api/student/login', (req, res) => {
  const { registrationNo, password } = req.body;

  const selectQuery = 'SELECT * FROM students WHERE RegNo = ?';
  db.query(selectQuery, [registrationNo], (err, results) => {
    if (err) {
      res.status(500).json({ error: err.message });
      return;
    }

    if (results.length === 0) {
      res.status(401).json({ message: 'Invalid credentials' });
      return;
    }

    const student = results[0];

    // Compare the provided password with the stored password
    if (password === student.Password) {
      const authToken = generateAuthToken(student.RegNo); // Generate token
      res.json({ authToken });
    } else {
      res.status(401).json({ message: 'Invalid credentials' });
    }
  });
});
app.get('/api/data', (req, res) => {
  const query = 'SELECT * FROM student';
  db.query(query, (err, results) => {
    if (err) {
      res.status(500).json({ error: err.message });
    } else {
      res.status(200).json(results);
    }
  });
});
app.post('/api/save-scanned-data', (req, res) => {
  const { registrationNo, subject, date } = req.body;

  // Check if the same data already exists in the database
  const checkQuery = `
    SELECT * FROM scanned_qr
    WHERE registrationNo = ? AND subject = ? AND date = ?
  `;

  db.query(checkQuery, [registrationNo, subject, date], (err, results) => {
    if (err) {
      console.error('Error checking data:', err);
      res.status(500).json({ error: 'An error occurred while checking data' });
      return;
    }

    if (results.length > 0) {
      res.status(409).json({ message: 'Data already exists' });
      return;
    } else {
      // Data doesn't exist, proceed to insert
      const insertQuery = `
        INSERT INTO scanned_qr (registrationNo, subject, date)
        VALUES (?, ?, ?)
      `;
    
      db.query(insertQuery, [registrationNo, subject, date], (err, result) => {
        if (err) {
          console.error('Error inserting data:', err);
          res.status(500).json({ error: 'An error occurred while saving data' });
          return;
        }
        console.log('Data inserted into MySQL table');
        res.json({ message: 'Data saved successfully' });
      });
    }
  });
});

// Add this endpoint to your existing server code
app.post('/api/addStudent', (req, res) => {
  const { name, course, dob, address, mobileNo } = req.body;

  // Insert the employee data into the database
  const insertQuery = 'INSERT INTO student (name, course, dob, address ,mobileNo) VALUES (?, ?, ?, ?, ?)';
  db.query(insertQuery, [name, course, dob, address,mobileNo], (err, result) => {
    if (err) {
      res.status(500).json({ error: err.message });
    } else {
      res.status(200).json({ message: 'Employee data added successfully' });
    }
  });
});


app.post('/api/generate-qr/:regno', (req, res) => {
  const regno = req.params.regno;
  const qrCodeData = req.body.qrCodeData;

  const qrCode = qr.image(qrCodeData, { type: 'png' });

  const imageBuffer = [];
  qrCode.on('data', chunk => {
    imageBuffer.push(chunk);
  });

  qrCode.on('end', () => {
    const qrCodeImageData = Buffer.concat(imageBuffer).toString('base64');

    const updateQuery = 'UPDATE student SET qr_code = ? WHERE regno = ?';
    db.query(updateQuery, [qrCodeImageData, regno], (err, result) => {
      if (err) {
        res.status(500).json({ error: err.message });
      } else {
        const qrCodeDataURL = `data:image/png;base64,${qrCodeImageData}`;
        res.status(200).json({ qrCodeDataURL });
      }
    });
  });
});
