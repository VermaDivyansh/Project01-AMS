import React, { useEffect } from 'react';
import { Html5QrcodeScanner } from 'html5-qrcode';

function QRScanner() {
  useEffect(() => {
    const readerDiv = document.getElementById('reader');
    const resultDiv = document.getElementById('result');

    if (readerDiv && resultDiv) {
      const scanner = new Html5QrcodeScanner('reader', {
        qrbox: {
          width: 250,
          height: 250,
        },
        fps: 20,
      });

      const success = (result) => {
        resultDiv.innerHTML = `
          <h2>Success!</h2>
          <p><a href="${result}">${result}</a></p>
        `;

        scanner.clear();
        readerDiv.remove();
      };

      const error = (err) => {
        console.error(err);
      };

      scanner.render(success, error);
    }
  }, []);

  return (
    <main>
      <div id="reader"></div>
      <div id="result"></div>
    </main>
  );
}

export default QRScanner;
