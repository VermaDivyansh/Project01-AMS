import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import QRCode from 'qrcode.react';

function AttendanceForm() {
  const { subject } = useParams(); // Get the subject from the path parameter
  const [registrationNo, setRegistrationNo] = useState('');
  const [qrCode, setQrCode] = useState('');
  const [errorMessage, setErrorMessage] = useState('');

  useEffect(() => {
    console.log('Subject:', subject); // Log the subject to the console
  }, [subject]);

  const generateQRCode = () => {
    if (registrationNo.trim() === '') {
      setErrorMessage('Please enter a valid registration number.');
      return;
    }

    // Generate QR code based on registrationNo, subject, and current date
    const currentDate = new Date().toLocaleDateString();
    const generatedQRCode = `Registration No: ${registrationNo} Subject: ${subject} Date: ${currentDate}`;
    setQrCode(generatedQRCode);
    setErrorMessage('');
  };

  return (
    <div className="container mt-5">
      <h2>Attendance Form - {subject}</h2>
      <div className="mb-3">
        <input
          type="text"
          className="form-control"
          placeholder="Student Registration No"
          value={registrationNo}
          onChange={(e) => setRegistrationNo(e.target.value)}
        />
        {errorMessage && <div className="text-danger">{errorMessage}</div>}
      </div>
      <div className="mb-3">
        <button className="btn btn-primary" onClick={generateQRCode}>Generate QR Code</button>
      </div>
      {qrCode && (
        <div className="text-center">
          <QRCode value={qrCode} size={200} />
        </div>
      )}
    </div>
  );
}

export default AttendanceForm;
