import React, { useState, useEffect } from 'react';

function StudentTable() {
  const [data, setData] = useState([]);

  useEffect(() => {
    fetch('https://10.104.127.74:5000/api/data')
      .then(response => response.json())
      .then(data => setData(data))
      .catch(error => console.error('Error fetching data:', error));
  }, []);

  function formatDate(dateString) {
    const date = new Date(dateString);
    const day = String(date.getDate()).padStart(2, '0');
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const year = date.getFullYear();
    return `${day}-${month}-${year}`;
  }

  async function generateAndSaveQRCode(student) {
    const qrCodeData = `Name:${student.name}\nRegNo: ${student.regno}\nCourse:${student.course}\nDOB:${formatDate(student.dob)}\nAddress:${student.address}\nMobile No:${student.mobileNo}`;

    const response = await fetch(`https://10.104.127.74:5000/api/generate-qr/${student.regno}`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ qrCodeData }),
    });

    if (response.ok) {
      const responseData = await response.json();

      // Update the qr_code field in the employee object
      student.qr_code = responseData.qrCodeDataURL;

      // Update the state to trigger a re-render
      setData(prevData => prevData.map(item => item.regno === student.regno ? student : item));

      console.log(`QR code image data saved for student ${student.name}`);
    } else {
      console.error('Failed to save QR code image data:', response.statusText);
    }
  }

  return (
    <div>
      <h1>Students Data</h1>
      <div className="table-responsive">
        <table className="table table-striped table-bordered">
          <thead>
            <tr>
              <th>Reg No</th>
              <th>Name</th>
              <th>Course Name</th>
              <th>Date of Birth</th>
              <th>Address</th>
              <th>Mobile No</th>
              <th>QR Code</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {data.map(student => (
              <tr key={student.regno}>
                <td>{student.regno}</td>
                <td>{student.name}</td>
                <td>{student.course}</td>
                <td>{formatDate(student.dob)}</td>
                <td>{student.address}</td>
                <td>{student.mobileNo}</td>
                <td>
              {student.qr_code && (
             <img
               src={student.qr_code}
               alt={`QR Code for ${student.name}`}
               width="100"
               height="100"
                 />
                 )}
               </td>
                <td>
                  <button
                    className="btn btn-primary"
                    onClick={() => generateAndSaveQRCode(student)}
                  >
                    Generate QR
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

export default StudentTable;
