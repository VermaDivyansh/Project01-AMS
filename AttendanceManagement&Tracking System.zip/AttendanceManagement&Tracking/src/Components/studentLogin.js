import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

function StudentLogin({ onLogin }) {
  const navigate = useNavigate();
  const [registrationNo, setRegistrationNo] = useState('');
  const [password, setPassword] = useState(''); // Input field for password

  const handleLogin = async () => {
    try {
      // Send registration number and password to the backend
      const response = await fetch('/api/student/login', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ registrationNo, password }),
      });

      if (response.ok) {
        const { authToken } = await response.json();
        onLogin(authToken);
        navigate('/student-dashboard');
      } else {
        console.error('Authentication failed');
      }
    } catch (error) {
      console.error('Error:', error);
    }
  };

  return (
    <div className="container mt-5">
      <h1>Student Login</h1>
      <div className="mb-3">
        <input type="text" className="form-control form-control-sm" style={{ maxWidth: '300px' }} placeholder="Registration No" value={registrationNo} onChange={(e) => setRegistrationNo(e.target.value)} />
      </div>
      <div className="mb-3">
        <input type="password" className="form-control form-control-sm" style={{ maxWidth: '300px' }} placeholder="Password" value={password} onChange={(e) => setPassword(e.target.value)} />
      </div>
      <button className="btn btn-primary" onClick={handleLogin}>Login</button>
    </div>
  );
}

export default StudentLogin;
