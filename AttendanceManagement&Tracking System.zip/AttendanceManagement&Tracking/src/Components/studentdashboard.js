import React from 'react';
import { Link } from 'react-router-dom';

function StudentDashboard() {
  return (
    <div className="container mt-5">
      <h2>Student Dashboard</h2>
      <Link to="/mark-attendance" className="btn btn-primary">Mark Attendance</Link>
    </div>
  );
}

export default StudentDashboard;
