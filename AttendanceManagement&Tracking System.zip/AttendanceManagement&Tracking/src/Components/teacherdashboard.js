import React, { useState } from 'react';
import { Link } from 'react-router-dom';

function TeacherDashboard() {
  const [selectedSubject, setSelectedSubject] = useState('');

  return (
    <div>
      <h1>Teacher Dashboard</h1>
      <h3>Select a Subject:</h3>
      <ul>
        <li>
          <Link to={`/attendance-form/java`} onClick={() => setSelectedSubject('Java')}>
            Java
          </Link>
        </li>
        <li>
          <Link to={`/attendance-form/dotnet`} onClick={() => setSelectedSubject('.NET')}>
            .NET
          </Link>
        </li>
        <li>
          <Link to={`/attendance-form/operating-system`} onClick={() => setSelectedSubject('Operating System')}>
            Operating System
          </Link>
        </li>
        {/* Add more subjects here */}
      </ul>
    </div>
  );
}

export default TeacherDashboard;
