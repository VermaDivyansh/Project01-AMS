import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom'; // Import useNavigate hook

function TeacherLogin({ onLogin }) {
  const navigate = useNavigate(); // Get the navigate function

  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');

  const handleLogin = () => {
    // Perform teacher login logic here
    // Assuming you get an authentication token for the teacher
    const authToken = 'teacher-auth-token'; // Replace with actual token
    onLogin(authToken);

    // Redirect to the teacher's dashboard
    navigate('/teacher-dashboard'); // Replace with actual dashboard route
  };

  return (
    <div className="container mt-5">
      <h1>Teacher Login</h1>
      <div className="mb-3">
        <input type="text" className="form-control form-control-sm" style={{ maxWidth: '300px' }} placeholder="Username" value={username} onChange={(e) => setUsername(e.target.value)} />
      </div>
      <div className="mb-3">
        <input type="password" className="form-control form-control-sm" style={{ maxWidth: '300px' }} placeholder="Password" value={password} onChange={(e) => setPassword(e.target.value)} />
      </div>
      <button className="btn btn-primary" onClick={handleLogin}>Login</button>
    </div>
  );
}

export default TeacherLogin;
