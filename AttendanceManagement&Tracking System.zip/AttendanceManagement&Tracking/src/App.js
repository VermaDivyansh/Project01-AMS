import React, { useState } from 'react';
import { BrowserRouter as Router, Route, Link, Routes } from 'react-router-dom';
import StudentForm from './ReactQR/studentForm';
import TeacherLogin from './ReactQR/teacherlogin';
import './ReactQR/App.css'
import StudentTable from './ReactQR/studenttable';
import QRScanner from './ReactQR/QRScanner';
import TeacherDashboard from './ReactQR/teacherdashboard'
import AttendanceForm from './ReactQR/attendanceForm';
import StudentLogin from './ReactQR/studentLogin';
import StudentDashboard from './ReactQR/studentdashboard';
function App() {
  const handleTeacherLogin = (authToken) => {
    // Perform necessary actions after teacher login
    console.log('Teacher logged in with token:', authToken);
    // You can store the token in state or perform other logic here
  };
  const handleStudentLogin = (authToken) => {
    // Perform necessary actions after teacher login
    console.log('Teacher logged in with token:', authToken);
    // You can store the token in state or perform other logic here
  };

  return (
    <Router>
      <body>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossOrigin="anonymous"></link>

        <nav className="navbar navbar-expand">
          <div className="container">
            <Link className="navbar-brand" to="/">Home</Link>
            <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
              <span className="navbar-toggler-icon"></span>
            </button>
            <div className="collapse navbar-collapse" id="navbarNav">
              <ul className="navbar-nav">
                <li className="nav-item">
                  <Link className="nav-link" to="/employee-table">Students Info</Link>
                </li>
              </ul>
              <ul className="navbar-nav">
                <li className="nav-item">
                  <Link className="nav-link" to="/teacherLogin">Teacher's Login</Link>
                </li>
              </ul>
              <ul className="navbar-nav">
                <li className="nav-item">
                  <Link className="nav-link" to="/studentlogin">Student Login</Link>
                </li>
              </ul>
            </div>
          </div>
        </nav>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-HwwvtgBNo3bZJJLYd8oVXjrBZt8cqVSpeBNS5n7C8IVInixGAoxmnlMuBnhbgrkm" crossOrigin="anonymous"></script>
      </body>
      <div className="container mt-4">
        <Routes>
          <Route
            path="/"
            element={
              <div>
                <h1>Welcome to Home Page</h1>
                <br />
                <StudentForm />
              </div>
            }
          />
          <Route path="/employee-table" element={<StudentTable />} />
          <Route path='/teacherLogin' element={<TeacherLogin onLogin={handleTeacherLogin} />} />
          <Route path='/teacher-dashboard' element={<TeacherDashboard/>}/>
          <Route path="/attendance-form/:subject" element={<AttendanceForm />} />
          <Route path='/studentlogin' element={<StudentLogin onLogin={handleStudentLogin} />}/>
          <Route path='/student-dashboard' element={<StudentDashboard/>}/>
          <Route path='/mark-attendance' element={<QRScanner/>}/>
        </Routes>
      </div>
    </Router>
  );
}

export default App;
