import React, { useState, useEffect } from 'react';

function App() {
  const [students, setStudents] = useState([]);
  const [presentStudents, setPresentStudents] = useState([]);
  const [selectedSubject, setSelectedSubject] = useState('');
  const [absentStudentsForSubject, setAbsentStudentsForSubject] = useState([]);
  const [notificationStatus,setNotificationStatus]=useState('');

  useEffect(() => {
    // Fetch students
    fetch('https://10.104.127.74:5000/api/students')
      .then(response => response.json())
      .then(data => {
        setStudents(data);
        console.log('Students', data); // Log students here
      })
      .catch(error => console.error('Error fetching students:', error));

    // Fetch scanned QR code entries for the current date
    fetch('https://10.104.127.74:5000/api/todayEntries')
      .then(response => response.json())
      .then(data => {
        setPresentStudents(data);
        console.log('Present Students', data); // Log presentStudents here
      })
      .catch(error => console.error('Error fetching QR code entries:', error));
  }, []);

  useEffect(() => {
    console.log('selectedSubject', selectedSubject);
  
    const studentToSubjectsMap = {};
  
    presentStudents.forEach(entry => {
      if (!studentToSubjectsMap[entry.registrationNo]) {
        studentToSubjectsMap[entry.registrationNo] = [];
      }
      studentToSubjectsMap[entry.registrationNo].push(entry.subject);
    });
  
    const absentStudents = students.filter(student => {
      const presentSubjects = studentToSubjectsMap[student.RegNo] || [];
      return !presentSubjects.includes(selectedSubject);
    });
  
    setAbsentStudentsForSubject(absentStudents);
    console.log('absentStudentsForSubject', absentStudents);
  }, [students, presentStudents, selectedSubject]);
  
  const handleSubjectChange = event => {
    setSelectedSubject(event.target.value);
  };

  const handleSendNotifications = () => {
    const dataToSend = {
      subject: selectedSubject,
      absentStudents: absentStudentsForSubject
    };
  
    fetch('https://10.104.127.74:5000/api/send-notifications', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(dataToSend),
    })
      .then(response => response.json())
      .then(data => {
        console.log('Notification sent successfully:', data);
        setNotificationStatus(`Notification sent successfully for ${selectedSubject}`);
      })
      .catch(error => {
        console.error('Error sending notifications:', error);
        setNotificationStatus(`Error sending notifications for ${selectedSubject}`);
      });
  };
  
  useEffect(() => {
    console.log('absentStudentsForSubject', absentStudentsForSubject);
  }, [absentStudentsForSubject]);
  
  return (
    <div className="container mt-5">
      <div className="text-center">
        <h1 className="text-center mb-4">Absent Students by Subject</h1>
        <div className="d-flex justify-content-center align-items-center mb-3">
          <label htmlFor="subjectSelect" className="me-3">Select Subject:</label>
          <select className='form-select' style={{ maxWidth: '300px' }} id="subjectSelect" value={selectedSubject} onChange={handleSubjectChange}>
            <option value="">Select a subject</option>
            <option value="java">Java</option>
            <option value="dotnet">DotNet</option>
            <option value="operating-system">Operating System</option>
          </select>
          <button className="btn btn-primary mb-6 ms-3" onClick={handleSendNotifications}>
               Send Notifications
           </button>
           {notificationStatus && (
            <p className={`mt-2 ${notificationStatus.includes('successfully') ? 'text-success' : 'text-danger'}`}>
              {notificationStatus}
            </p>
            )}
        </div>
      </div>
      {selectedSubject && (
        <div>
          <h3>Absent Students for {selectedSubject}</h3>
          <table className="table table-bordered table-striped">
            <thead>
              <tr>
                <th>Reg No</th>
                <th>Student Name</th>
                <th>Student Email</th>
                <th>Parent Email</th>
              </tr>
            </thead>
            <tbody>
              {absentStudentsForSubject.map(student => (
                <tr key={student.RegNo}>
                  <td>{student.RegNo}</td>
                  <td>{student.FirstName} {student.LastName}</td>
                  <td>{student.Email}</td>
                  <td>{student.ParentEmail}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

export default App;
